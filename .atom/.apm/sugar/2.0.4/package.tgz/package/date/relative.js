'use strict';

var Sugar = require('sugar-core'),
    dateRelative = require('./internal/dateRelative');

Sugar.Date.defineInstance({

  'relative': function(date, localeCode, fn) {
    return dateRelative(date, null, localeCode, fn);
  }

});

module.exports = Sugar.Date.relative;