'use strict';

var Sugar = require('sugar-core'),
    updateDate = require('./internal/updateDate'),
    collectDateArguments = require('./internal/collectDateArguments');

Sugar.Date.defineInstanceWithArguments({

  'set': function(d, args) {
    args = collectDateArguments(args);
    return updateDate(d, args[0], args[1]);
  }

});

module.exports = Sugar.Date.set;