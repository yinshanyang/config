'use strict';

var updateDate = require('./updateDate'),
    collectDateArguments = require('./collectDateArguments');

function advanceDateWithArgs(d, args, dir) {
  args = collectDateArguments(args, true);
  return updateDate(d, args[0], args[1], dir);
}

module.exports = advanceDateWithArgs;