'use strict';

module.exports = /(\w{3})[()\s\d]*$/;