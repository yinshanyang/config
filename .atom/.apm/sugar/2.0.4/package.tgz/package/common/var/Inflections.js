'use strict';

module.exports = {};