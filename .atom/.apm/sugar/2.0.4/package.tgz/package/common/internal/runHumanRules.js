'use strict';

var Inflections = require('../var/Inflections');

function runHumanRules(str) {
  return Inflections.human && Inflections.human.runRules(str) || str;
}

module.exports = runHumanRules;