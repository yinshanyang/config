'use strict';

var Inflections = require('../var/Inflections');

function getHumanWord(str) {
  return Inflections.human && Inflections.human.find(str);
}

module.exports = getHumanWord;