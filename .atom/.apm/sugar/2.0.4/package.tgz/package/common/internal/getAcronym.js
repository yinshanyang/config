'use strict';

var Inflections = require('../var/Inflections');

function getAcronym(str) {
  return Inflections.acronyms && Inflections.acronyms.find(str);
}

module.exports = getAcronym;