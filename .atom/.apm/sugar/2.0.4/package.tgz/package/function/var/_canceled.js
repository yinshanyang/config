'use strict';

var privatePropertyAccessor = require('../../common/internal/privatePropertyAccessor');

module.exports = privatePropertyAccessor('canceled');