'use strict';

var Sugar = require('sugar-core'),
    arrayGroupBy = require('./internal/arrayGroupBy');

Sugar.Array.defineInstance({

  'groupBy': function(arr, map, fn) {
    return arrayGroupBy(arr, map, fn);
  }

});

module.exports = Sugar.Array.groupBy;