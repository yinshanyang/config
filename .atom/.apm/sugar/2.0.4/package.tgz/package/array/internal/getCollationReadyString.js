'use strict';

var classChecks = require('../../common/var/classChecks');

var isString = classChecks.isString;

function getCollationReadyString(str, sortIgnore, sortIgnoreCase) {
  if (!isString(str)) str = String(str);
  if (sortIgnoreCase) {
    str = str.toLowerCase();
  }
  if (sortIgnore) {
    str = str.replace(sortIgnore, '');
  }
  return str;
}

module.exports = getCollationReadyString;